__docformat__ = "restructuredtext"
__version__ = "0.4.0"

__doc__ = """
This<https://github.com/WinVector/wvu> is a package of examples and plots for teaching data science.
"""

# allows import wvu to grant access to wvu.util
import wvu.util as util

