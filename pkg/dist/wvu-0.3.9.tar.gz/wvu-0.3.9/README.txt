Win Vector LLC tools for doing and teaching data science in Python 3
https://github.com/WinVector/wvpy

Some notes can be found here: https://github.com/WinVector/wvpy
and here: https://win-vector.com/2022/08/20/an-effective-personal-jupyter-data-science-workflow/


